# WemosD1_HomeMatic_RFID

Informationen rund um dieses Projekt gibts im [Wiki](https://github.com/jp112sdl/WemosD1_HomeMatic_RFID/wiki)

**MFRC522**<br>
![rfid](Images/rfid.jpg)
<br>**RDM6300**<br>
![rfid_rdm6300](Images/rfid_rdm6300.jpg)
